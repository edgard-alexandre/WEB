<html>
	<head>
		<title>
			<?php echo $mensager ?>
		</title>
	</head>
<body>
	<h1><?php echo $mensagem ?></h1>
</body>
</html>
