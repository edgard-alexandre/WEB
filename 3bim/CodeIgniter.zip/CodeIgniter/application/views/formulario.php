<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset = "utf-8">
		<title>QUE NÃO VAI DAR O QUE</title>
		<link rel="stylesheet" href="formulario.css">
	</head>
	<body>
		<a href = "index.html">Inicio</a>
		<p>Inserir Nova Referência</p>
		<hr>
		<?php
			echo form_open(base_url('citacoes/adicionar'),$atributos) .
				form_label("Nome do Arquivo:","txt_nomeArquivo") . br () .
				form_input('txt_nomeArquivo') . br () .
				form_submit("btn_enviar","Cadastrar nova postagem") .
				form_close();
		?>
	</body>
</html>
