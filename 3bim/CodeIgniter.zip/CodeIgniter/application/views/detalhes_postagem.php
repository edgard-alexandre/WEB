<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
			<title>Meu blog</title>
	</head>
	<body>
		<h2>Meu blog</h2>
		<h3><?php echo $postagem[0]->titulo ?></h3>
		<h3><?php echo $postagem[0]->texto ?></h3>
		<h3><?php echo $postagem[0]->dataCadastro ?></h3>
	
		<?php
			foreach($postagens as $post){
				$lista_urls[] = anchor(base_url("detalhes/".$post->id), $post->titulo);
			}
			echo ul($lista_urls);
		?>		
	</body>
</html>
				

