<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
			<title>Meu blog</title>
	</head>
	<body>
		<h2>Meu blog</h2>
		<?php
			foreach($postagens as $post){
				//echo "<h3>" . $post->titulo . "</h3>";
				//echo "<p>" . $post->texto . "</p>";
				//echo "<p>" . $post->dataCadastro . "</p>";
				//echo "<hr>";
			$lista_urls[] = anchor(base_url("detalhes/".$post->id), $post->titulo);
		}
			echo ul($lista_urls);
		?>

		<?php
			echo anchor(base_url(), "home").anchor(base_url)("fale-conosco"). "Fale conosco");
		?>
	</body>
</html>
				

