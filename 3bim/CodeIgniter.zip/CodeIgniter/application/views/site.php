<?php
$this->load->view('includes/header');
$this->load->view('includes/'.$view_principal);
$this->load->view('includes/footer');