<div id="homebody">
	<div class="alinhado-centro borda-base espaco-vertical">
		<h3>Seja Bem-Vindo à nossa loja.</h3>
		<p>A melhor loja de comida, especiarias e temperos. Compre online e receba em casa.</p>
		<a class="btn btn-medium btn-sucess" href="#">Cadastre-se</a>
	</div>
	<div class="row-fluid">
	<div class="span4">
		<h3>Destaque 1</h3>
		<p>Produto 1 em destaque na loja.</p>
		<a class ="btn">Detalhes</a>
	</div>
	<div class="span4">
		<h3>Destaque 2</h3>
		<p>Produto 2 em destaque na loja.</p>
		<a class="btn">Detalhes</a>
	</div>
	<div class="span4">
		<h3>Destaque 3</h3>
		<p>Produto 3 em destaque na loja.</p>
		<a class ="btn">Detalhes</a>
	</div>
</div>
