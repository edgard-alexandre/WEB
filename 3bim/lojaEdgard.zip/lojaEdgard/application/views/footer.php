	<div id ="footer" class="borda-topo espaco-vertical">
		&copy;<?php echo date("Y");?>-Todos os direitos reservados.
	</div>
