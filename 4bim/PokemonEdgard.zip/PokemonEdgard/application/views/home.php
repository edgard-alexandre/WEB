<!DOCTYPE html>
<html lang="pt-br">
    <head>
	   <meta charset="UTF-8">
	   <title>PokéControl</title>
        <link rel="stylesheet" type="text/css" href="http://localhost/PokemonEdgard/assets/arquivo.css">
    </head>
    <body background="http://localhost/PokemonEdgard/assets/images/fundo.jpg" width="100%" style="background-repeat: no-repeat">
        <p class="titulo">PokéControl</p>
        <img src='http://localhost/PokemonEdgard/assets/images/pikachu.png' id='pikachu'>
        <img src='http://localhost/PokemonEdgard/assets/images/pokemongo2.png' id='logo'>
        <p id="boasvindas">Seja bem-vindo ao mais novo gerencidor e controlador POKÉMON.</p>
        <p id="boasvindas2"> Aqui você poderá registrar e visualizar toda a sua lista de pokémons, tendo todo o controle com maior facilidade e praticidade. Para isso, basta fazer o login logo abaixo:</p>
         <div>
            <?php
                echo form_open(base_url('pokemon/adicionar') , array('id'=>'form_cadastro'))."<div class='span4 '>" . form_input(array('id'=>'nome','name'=>'nome','Placeholder'=>'Nome','value'=>set_value( 'nome'))) . form_input(array('id'=>'sobrenome','name'=>'sobrenome','Placeholder'=>'Sobrenome','value'=> set_value('sobrenome'))) . form_submit('btn_cadastrar','Cadastrar')."</div>" . form_close();
             ?>
        </div>
    </body>
</html>    